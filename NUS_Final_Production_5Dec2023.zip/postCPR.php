<?php
include_once 'security.php';
include('dbconn.php');
error_reporting(E_ERROR | E_PARSE);
$month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
$totalconsSum_CPR = 0;
$parent_CPR = $_POST['parentid'];
$country_CPR = $_POST['country_CPR'];
$client_CPR = $_POST['resSelectedClient_CPR']; //displat all/multiple/name
$contract_CPR = $_POST['resSelectedContracts_CPR']; //displat all/multiple/name
//  $commodity = $rowIER['commodityName'];
$clientId = $_POST["clientcheckbox_CPR"];
sort($clientId);
$commodity = $_POST["commodity_CPR"];
$year = $_POST['yearstype_CPR'];
$contract_arr = $_POST['contractcheckbox_CPR'];
sort($contract_arr);
$contracts = implode(",", $contract_arr);

// echo "<pre>contract";
// print_r($contract_arr);
// echo $client_CPR;
// ($contract_CPR != 'All' && $contract_CPR != 'Multiple') ? $title = 'title = "' . $contract_CPR . '"' : $title = '';

($client_CPR != 'All' && $client_CPR != 'Multiple') ? $titleC = 'title = "' . $client_CPR . '"' : $titleC = '';

$supplierId_CPR = $_POST["contractcheckbox_CPR"];
//  print_r($_POST["contractcheckbox_CPR"]);
//  $year_CPR = implode('', $_POST['yearstype_CPR']);
$implodeSupplierId_CPR = implode(',', $supplierId_CPR); // to pass values in IN operator
$clients_CPR = $_POST['clientcheckbox_CPR'];
//  print_r($clients);
//  echo count($clients);
//  echo $implode;
//  echo $monthsExplode[0];
$totalconsumtion = [];
$sqlQuery_CPR = "SELECT * FROM nus_supply_contract 
 INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
 WHERE supplierId IN ($implodeSupplierId_CPR)";
// echo $sqlQueryIER;
$result_CPR = mysqli_query($conn, $sqlQuery_CPR);
$row_CPR = mysqli_fetch_assoc($result_CPR);
if($contract_CPR != 'All' && $contract_CPR != 'Multiple') {
    $contract_CPR = $row_CPR['contract_id'];
}

$sqlConsumption_CPR = "SELECT totalAnualConsumption FROM nus_supply_contract WHERE supplierId IN ($implodeSupplierId_CPR)";
$resultCons_CPR = mysqli_query($conn,  $sqlConsumption_CPR);


while ($rowcons = mysqli_fetch_assoc($resultCons_CPR)) {
    $consSum = floatval(str_replace(',', '', $rowcons['totalAnualConsumption']));
    $totalconsSum_CPR = $totalconsSum_CPR + $consSum;
}

$monthSelected = $_POST['allselectedmonths'];
$monthsExplode = explode(',', $monthSelected);

// echo "<pre>";
// print_r($monthsExplode);


$months_unhedge_effect = $_POST['unhedgeValues'];
//  $months_unhedge_effec_explode= explode(',', $months_unhedge_effect);
// echo "<pre>";
// print_r($months_unhedge_effect);
$unhedged_eff_wap = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

for ($i = 0; $i < count($monthsExplode); $i++) {
    // echo "type==>".gettype($month[$i])."<br>";
    $a = array_search($monthsExplode[$i], $month);

    if (isset($a)) {
        // echo $a . "\n";
        // echo "monthindex" . $a . "month==>" . $months_unhedge_effect[$a] . "<br>";
        $unhedged_eff_wap[$a] = (float)str_replace(",", "", $months_unhedge_effect[$i]);
    }
}
// echo "wap<pre>";
// print_r($unhedged_eff_wap);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <script src="common_files/ajax_googleapsis_jquery_3.6.0.js"></script>
    <link rel="stylesheet" src="common_files/datatable.css"> -->
    <!-- <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" /> -->
<link rel="stylesheet" href="common_files/jquery_datatable_min.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- <script src="common_files/jquery_3.6.0.js"></script>
<script src="common_files/dataTable_1.12.1.js"></script> -->


</head>
<style>
    .chart {
        margin-bottom: 50px;
    }

    ul li {

        width: 25%;

        white-space: nowrap;

        overflow: hidden;

    }



    li h2 {

        margin: 0;

        overflow: hidden;

        text-overflow: ellipsis;

    }



    /* last table css */

    .tableIER,

    .tableIERCommon {

        width: 80%;
        margin-bottom: 50px;
        /* font-size: 12px; */

    }




    .tableIER th,

    .consolidatedTable th,

    .tableIERCommon th {

        background-color: rgba(238, 237, 237, 0.9);

        text-align: left;
        padding: 8px;

    }

    .tableIERCommon th {
        text-align: right;
    }


    .tableIER .lastHeadIER {

        text-align: right;

    }



    .tableIER tr td {

        text-align: left;
        padding: 8px;

    }



    .tableIERCommon tr td {

        text-align: right;
        padding: 8px;

    }

    #tableIERconsolidated tr td,
    #tableIERclient tr td {
        padding: 8px;
    }

    #tableIERconsolidated tr td:nth-child(1) {
        width: 30%
    }

    #tableIERclient tr td:nth-child(1) {
        width: 20%
    }


    .tableIER tr .lasttdIER {

        text-align: right;

    }



    .headrightAlign {

        text-align: right;

        background-color: red;

    }



    .columGreyTd {

        background-color: rgba(238, 237, 237, 0.9);

        text-align: right;

    }

    .dataTables_length,
    .dataTables_info {
        /* background-color: red; */
        margin: 0 0 0 10%;
        padding: 0 0 1% 0;
    }

    .dataTables_filter,
    .dataTables_paginate {
        margin: 0 10% 0 0;
        padding: 0 0 1% 0;
    }

    .dataTables_wrapper {
        font-size: 0.85rem;
    }

    article {
        margin-bottom: 50px;
    }

    /* #mytable{
        font-size: 14px;
        background-color: red;
    } */
</style>

<body>
   


    <?php
    // include_once 'security.php';
    include('dbconn.php');

    $contract_est = [];
    $contract_hedge = [];
    $contractId = [];


    // $contracts = "81";
    // $clientId = [36];
    // $contracts = "12,14,44,33";
    // $unhedged_eff_wap = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100];
    // $year = 2023;
    // echo "Comm==>".$commodity_CPR;
    $client_contract1 = array();
    $client_contract2 = array();
    $contract1 = array();
    $clientId1 = array();
    $clientId2 = array();
    $supplier_contract = array();
    // echo "<pre>";
    // echo "clinetid";
    // print_r($clientId);
    // echo "contracts";
    // print_r($contract_arr);

    for ($i = 0; $i < count($clientId); $i++) {
        // array_push($client_contract1, array());
        $sqlQuery1 = "SELECT * FROM nus_supply_contract 
        WHERE nus_supply_contract.clientId = $clientId[$i] AND nus_supply_contract.commodityName = '" . $row_CPR['commodityName'] . "'";
        // echo $sqlQuery1."<br>";
        $result1 = mysqli_query($conn, $sqlQuery1);
        while ($row1 = mysqli_fetch_assoc($result1)) {

            if (array_search($row1["supplierId"], $contract_arr) != "") {
                // $clientName1[$i] = $row1["clientcompany"];
                // echo "contractss=".$row1["supplierId"]."<br>";
                $client_contract2[$i][] = $row1["contract_id"];
                $contract1[] = $row1["supplierId"];
                $clientId2[] = $clientId[$i];
                $supplier_contract[$i][] = $row1['supplierId'];
            }
        }
    }
    $clientId2 = array_unique($clientId2);
    $supplier_contract1=[];
    $oo = 0;
    foreach ($supplier_contract as $value) {
        $supplier_contract1[$oo] = $value;
        $oo++;
    }
//      echo "<pre>";
// print_r($supplier_contract1);
$contrac=array();
for($j=0;$j<count($supplier_contract1);$j++){

    for($k=0; $k<count($supplier_contract1[$j]); $k++){
        $contrac[] = $supplier_contract1[$j][$k];
    }
}
// print_r($contrac);
$contracts = implode(",",$contrac);
// echo $contracts;
    $oo = 0;
    foreach ($clientId2 as $value) {
        $clientId1[$oo] = $value;
        $oo++;
    }
    // print_r($clientId1);
    $oo = 0;
    foreach ($client_contract2 as $value) {
        $client_contract1[$oo] = $value;
        $oo++;
    }

    // echo $contracts;
    // print_r($client_contract1);
    // print_r($clientId1);
    // echo "clinet";
    // echo implode(",",$contract1)."<br>";
    // $contracts = "20,19,17";
    // for($i=0;$i<count($clientId);$i++){
for($i=0; $i<count($contrac); $i++){

            $sqlQueryCPR = "SELECT * FROM nus_supply_contract 
INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
WHERE nus_supply_contract.supplierId = $contrac[$i]  AND nus_supply_contract.commodityName = '" . $row_CPR['commodityName'] . "'";
    $resultCPR = mysqli_query($conn, $sqlQueryCPR);

    while ($rowCPR = mysqli_fetch_assoc($resultCPR)) {
        // $b = array_search($rowCPR['clientId'], $clientId);
        // echo $rowCPR["contract_id"];
        $contract_est[] = $rowCPR["consumptionmonth"];
        $contract_hedge[] = $rowCPR["hedgeconsumption"];
        $contractId[] = $rowCPR["contract_id"];
    }
    }
    // echo "<pre>";
    // print_r($contracts);
    // print_r($contract_est);
    // print_r($contract_hedge);
    $est_all = array();
    $hedge_all = array();
    $totaleffective_commodity = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    $multy_est = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_open = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_perchedge = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_peropen = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_hedged_eff_wap = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_unhedged_eff_wap = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_port_eff_price = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_hedged_eff_commodity_cost = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_unhedged_eff_commodity_cost = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_est_portfilio_commodity_cost = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $hedge_effective_wap = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $unhedge_effective_commodity_cost = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $est_Portfolio_Commodity_Cost = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $port_effective_price = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $total_est = 0;
    $total_hedge = 0;
    $total_open = 0;
    $total_perc_hedge = 0;
    $total_perc_open = 0;
    $total_hedge_effective_wap = 0;
    $total_unhedge_effective_wap = 0;
    $total_port_effective_price = 0;
    $total_hedge_commodity_cost = 0;
    $total_unhedge_commodity_cost = 0;
    $total_portfolio_commodity_cost = 0;
    for ($m = 0; $m < 12; $m++) {
        $total_unhedge_effective_wap += round((float)$unhedged_eff_wap[$m], 2);
    }
    $total_unhedge_effective_wap = (float)$total_unhedge_effective_wap / 12;

    for ($j = 0; $j < count($contract_est); $j++) {

        $est = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $month_consumtion =  array();
        $month_hedged = array();
        $month1 = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];

        $consumption = explode('|', $contract_est[$j]);
        $hedged = explode('|', $contract_hedge[$j]);

        for ($i = 0; $i < count($consumption); $i++) {
            $month_consumtion[$i] = explode('-', $consumption[$i]);
            $month_hedged[$i] = explode('-', $hedged[$i]);
        }
        // echo "<pre>.month";
        // print_r($month_hedged);
        for ($i = 0; $i < count($month_consumtion); $i++) {


            if ($month_consumtion[$i][1] == $year) { //emergency. for perticular year

                $a = array_search($month_consumtion[$i][0], $month1);

                $est[$a] = (float)$est[$a] + (float)$month_consumtion[$i][2];
                $hed[$a] = (float)$hed[$a] + str_replace(",", "", (float)$month_hedged[$i][2]);
                // echo $month_hedged[$i][2]."/";
                $multy_est[$a] += round((float)$est[$a],2);
                $multy_hed[$a] +=round((float)$hed[$a],2);
            } //emergency
            // echo "new";
            // print_r($est);

        }
        // echo "<pre>";
        // print_r($month_hedged);
        $est_all[$j] = $est;
        $est_hedge[$j] = $hed;
    }
    //     echo "<pre>";
    // echo "hedge";
    // print_r($multy_hed);
    // echo "Est";
    // print_r($multy_est);
    for ($i = 0; $i < 12; $i++) {

        $multy_open[$i] = round((float)$multy_est[$i] - (float)$multy_hed[$i], 2);
        if ($multy_est[$i] == 0) {
            $multy_perchedge[$i] = 0;
        } else {
            $multy_perchedge[$i] = round(((float)$multy_hed[$i] / (float)$multy_est[$i]) * 100, 2);
        }
        if ($multy_est[$i] == 0) {
            $multy_peropen[$i] = 0;
        } else {
            $multy_peropen[$i] = round(((float)$multy_open[$i] / (float)$multy_est[$i]) * 100, 2);
        }
    }

    // echo "<pre>hi";
    // print_r($client_contract1);
    // print_r($client_contract1);
    // print_r($contractId);



    // echo "<pre>";
    // echo "clientid";
    // print_r($clientId1);
    // echo "estimation";
    // print_r($est_all);
    $l = 0;
    // echo "count".count($client_contract1);
    for ($n = 0; $n < count($client_contract1); $n++) {

        //   echo "ji=>".$n;

        for ($i = 0; $i < count($client_contract1[$n]); $i++) {
            // echo "Bapaaa";
            $min = 0;
            $max = 0;
            $numarator = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            $denominator = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            $effiective_wap = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            $effiective_commodity = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

            // echo "YOYUO".$clientId[$i]."<br>";
            // echo "clientC".$client_contract1[$n][$i]."\n";
            $supplycontract = $client_contract1[$n][$i];

            $sqlQuerytrade = "SELECT * FROM enter_trade WHERE supplycontractid = '$supplycontract' AND tradeexecuted = 'executed' AND tradevalue = $year AND clientId = $clientId1[$n];";
            // echo $sqlQuerytrade."\n";

            $resulttrade = mysqli_query($conn, $sqlQuerytrade);

            while ($rowtrade = mysqli_fetch_assoc(($resulttrade))) {
                // while($rowtrade = mysqli_fetch_assoc($resulttrade)){


                // echo "<pre>";
                // print_r($rowtrade);
                if ($rowtrade["trade"] == "Calendar Yearly") {
                    $min = 0;
                    $max = 12;
                } else if ($rowtrade["trade"] == "Calendar Quarterly") {
                    if ($rowtrade["quartval"] == 'q1') {
                        $min = 0;
                        $max = 3;
                    } else if ($rowtrade["quartval"] == 'q2') {
                        $min = 3;
                        $max = 6;
                    } else if ($rowtrade["quartval"] == 'q3') {
                        $min = 6;
                        $max = 9;
                    } else if ($rowtrade["quartval"] == 'q4') {
                        $min = 9;
                        $max = 12;
                    }
                } else if ($rowtrade["trade"] == "Calendar Monthly") {
                    $min = array_search($rowtrade['quartval'], $month1);
                    $max = $min + 1;
                }

                // echo "Year Month";
                // echo $min;
                // echo $max."\n";

                // echo "<pre>ye";

                // echo "<br>";

                for ($j = $min; $j < $max; $j++) {
                    // $contract_est[$j];
                    // $contract_hedge[$j];
                    // echo "<pre>";


                    // if ($rowtrade["percentage"] > 0) {
                    // echo $rowtrade["tradevolume"]."/";
                    if ($rowtrade["percentage"] > 0) {

                        $perc = round((float)$rowtrade["percentage"], 2) / 100;
                        $numarator[$j] += (float)$est_all[$i][$j] * (float)$perc * (float)$rowtrade["effectiveprice"];
                        $denominator[$j] += (float)$est_all[$i][$j] * $perc;
                        // echo "est=>".$est_all[$n][$j]."perc=>".$perc."eff=>".$rowtrade["effectiveprice"];

                        // echo $perc;
                    } else if ($rowtrade["mwh"] > 0) {

                        $total_month = $max - $min;
                        if ($total_month == 0) {
                            $mwh = 0;
                        } else {
                            $mwh = round((float)$rowtrade["tradevolume"], 2) / (float)$total_month;
                        }

                        $numarator[$j] += $mwh * $rowtrade["effectiveprice"];
                        $denominator[$j] += $mwh;
                    } else if ($rowtrade["mw"] != "0.00") {

                        if ($year % 4 == 0) {
                            $days = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                        } else {
                            $days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                        }
                        $numarator[$j] += round($rowtrade["mw"], 2) * $days[$j] * 24 * $rowtrade["effectiveprice"];
                        $denominator[$j] += round($rowtrade["mw"], 2) * $days[$j] * 24;
                        if ($j == 4) {
                            // echo "mw=>".$rowtrade["mw"]."days=>".$days[$j]."eff=>".$rowtrade["effectiveprice"];
                        }
                    }
                }
                // $l++;


            }
            //   echo "numerator<pre>";
            //   print_r($numarator);
            //   echo "denominator";
            //   print_r($denominator);
            // echo "estimation";
            // print_r($est_all);
            // echo $l;

            for ($j = 0; $j < 12; $j++) {
                if ($denominator[$j] == 0) {
                    $effiective_wap[$j] = 0;
                } else {
                    $effiective_wap[$j] =  (float)$numarator[$j] / (float)$denominator[$j];
                }
                // if ($effiective_wap[$j] == 0) {
                //     $effiective_commodity[$j] = 0;
                // } else {
                    $effiective_commodity[$j] = round((float)$est_hedge[$l][$j], 2) * round((float)$effiective_wap[$j], 2);
                    // echo "f".$est_hedge[$l][$i];
                // }
                $totaleffective_commodity[$j] += (float)$effiective_commodity[$j];
                // total unhedge effective price
                // $total_unhedge_effective_wap += $unhedged_eff_wap[$j]; 

            }
            // echo "<pre>";
            // echo "commodity";
            // print_r($effiective_wap);
           
            // $total_unhedge_effective_wap =  $total_unhedge_effective_wap / 12;
            // echo $j;
            // echo "<pre>total";
            // print_r($effiective_wap);
            $l++;
        }
    }
    // echo "hedge<pre>";
    // print_r($est_hedge);
    // echo "<pre>";
    // print_r($totaleffective_commodity);
    $m = 1;
    $unhedge = 0;
    $unhedge_eff = array();

    for ($i = 0; $i < 12; $i++) {
        if ($multy_hed[$i] == 0) {
            $hedge_effective_wap[$i] = 0;
        } else {
            // echo "Bapa ===> ".round($totaleffective_commodity[$i],2)."<br/>";
            $hedge_effective_wap[$i] = ((float)$totaleffective_commodity[$i] / (float)$multy_hed[$i]);
            // echo"hedge=====".$hedge_effective_wap[$i]."<br>";
        }

        $unhedge_effective_commodity_cost[$i] = round((float)$unhedged_eff_wap[$i] * (float)$multy_open[$i], 2);


        $est_Portfolio_Commodity_Cost[$i] = round((float)$totaleffective_commodity[$i]) + round((float)$unhedge_effective_commodity_cost[$i]);

        if ($multy_est[$i] == 0) {
            $port_effective_price[$i] = 0;
        } else {
            $port_effective_price[$i] = round((float)$est_Portfolio_Commodity_Cost[$i] / (float)$multy_est[$i], 2);
        }
        // echo "<pre>";
        // print_r($unhedge_effective_commodity_cost);
        //    total calculation
        $total_est += round((float)$multy_est[$i], 2);
        $total_hedge += round((float)$multy_hed[$i], 2);
        $total_hedge_commodity_cost += round((float)$totaleffective_commodity[$i]);
        $total_unhedge_commodity_cost += round((float)$unhedge_effective_commodity_cost[$i]);
        $total_portfolio_commodity_cost += round((float)$est_Portfolio_Commodity_Cost[$i]);
        // echo $total_unhedge_commodity_cost."<br>";
        // if ($unhedged_eff_wap[$i] > 0) {
        //     $unhedge += (float)$unhedged_eff_wap[$i];
        //     if ($m == 0) {
        //         $total_unhedge_effective_wap = 0;
        //     } else {
        //         $total_unhedge_effective_wap = round((float)$unhedge / (float)$m, 2);
        //     }

        //     $m++;
        // } else {
        //     $total_unhedge_effective_wap = 0;
        // }
        $unhedge_eff[$i] = $unhedged_eff_wap[$i];
    }
    // echo "<pre>";
    // echo "effect_commodity";
    // print_r($unhedged_eff_wap);
    // echo "unhedge_commodot";
    // print_r($multy_open);

    sort($unhedge_eff);
    $total_unhedge_effective_wap = $unhedge_eff[count($unhedge_eff) - 1];
    // echo "<pre>unhedge";
    // print_r($unhedge_eff);
    $total_open = round((float)$total_est - (float)$total_hedge, 2);
    if ($total_est == 0) {
        $total_perc_hedge = 0;
    } else {
        $total_perc_hedge = round(((float)$total_hedge / (float)$total_est) * 100, 2);
    }

    if ($total_est == 0) {
        $total_perc_open = 0;
    } else {
        $total_perc_open = round(((float)$total_open / (float)$total_est) * 100, 2);
    }

    if ($total_hedge == 0) {
        $total_hedge_effective_wap = 0;
    } else {
        $total_hedge_effective_wap = round((float)$total_hedge_commodity_cost / (float)$total_hedge, 2);
    }
    // echo "hedge commodity".$total_hedge_commodity_cost."hedge".$total_hedge
    //    $total_unhedge_commodity_cost = round((float)$total_unhedge_effective_wap * (float)$total_open,2);
    //    $total_portfolio_commodity_cost = round((float)$total_hedge_commodity_cost + (float)$total_unhedge_commodity_cost,2);
    if ($total_est == 0) {
        $total_port_effective_price = 0;
    } else {
        $total_port_effective_price = round((float)$total_portfolio_commodity_cost / (float)$total_est, 2);
    }

    // echo "<pre>";
    // print_r($numarator);
    // print_r($denominator);
    // print_r($effiective_wap);
    // print_r($effiective_commodity);
    // print_r($totaleffective_commodity);

    // Quarterly calculation
    if ($_POST['view_CPR'] == "Quarterly") {
        // echo "<pre>";
        // print_r($totaleffective_commodity);
        $est_quarter = array();
        $hedge_quarter = array();
        $hedge_commodity_cost_quarter = array();
        $open_quarter = array();
        $perc_hedge_quarter = array();
        $perc_open_quarter = array();
        $unhedge_effective_wap_quarter = array();
        $hedge_effective_wap_quarter = array();
        $unhedge_commodity_cost_quarter = array();
        $portfolio_commodity_cost_quarter = array();
        $port_effective_price_quarter = array();

        $unhedge_q1 = array(0, 0, 0);
        $unhedge_q2 = array(0, 0, 0);
        $unhedge_q3 = array(0, 0, 0);
        $unhedge_q4 = array(0, 0, 0);

        for ($i = 0; $i < 12; $i++) {
            if ($i < 3) {
                $est_quarter[0] += round((float)$multy_est[$i],2);
                $hedge_quarter[0] += round((float)$multy_hed[$i],2);
                $hedge_commodity_cost_quarter[0] += round((float)$totaleffective_commodity[$i]);
                $unhedge_effective_wap_quarter[0] += (float)$unhedged_eff_wap[0];
                $unhedge_q1[] = $unhedged_eff_wap[$i];
            } else if ($i < 6) {
                $est_quarter[1] += round((float)$multy_est[$i],2);
                $hedge_quarter[1] += round((float)$multy_hed[$i],2);
                $hedge_commodity_cost_quarter[1] += round((float)$totaleffective_commodity[$i]);
                $unhedge_effective_wap_quarter[1] += (float)$unhedged_eff_wap[0];
                $unhedge_q2[] = $unhedged_eff_wap[$i];
            } else if ($i < 9) {
                $est_quarter[2] += round((float)$multy_est[$i],2);
                $hedge_quarter[2] += round((float)$multy_hed[$i],2);
                $hedge_commodity_cost_quarter[2] += round((float)$totaleffective_commodity[$i]);
                $unhedge_effective_wap_quarter[2] += (float)$unhedged_eff_wap[0];
                $unhedge_q3[] = $unhedged_eff_wap[$i];
            } else if ($i < 12) {
                $est_quarter[3] += round((float)$multy_est[$i],2);
                $hedge_quarter[3] += round((float)$multy_hed[$i],2);
                $hedge_commodity_cost_quarter[3] += round((float)$totaleffective_commodity[$i]);
                $unhedge_effective_wap_quarter[3] += (float)$unhedged_eff_wap[0];
                $unhedge_q4[] = $unhedged_eff_wap[$i];
            }
        }

        sort($unhedge_q1);
        sort($unhedge_q2);
        sort($unhedge_q3);
        sort($unhedge_q4);

        $unhedge_effective_wap_quarter[0] = (float)$unhedge_q1[count($unhedge_q1) - 1];
        $unhedge_effective_wap_quarter[1] = (float)$unhedge_q2[count($unhedge_q2) - 1];
        $unhedge_effective_wap_quarter[2] = (float)$unhedge_q3[count($unhedge_q3) - 1];
        $unhedge_effective_wap_quarter[3] = (float)$unhedge_q4[count($unhedge_q4) - 1];

        for ($i = 0; $i < 4; $i++) {
            $open_quarter[$i] = round((float)$est_quarter[$i] - (float)$hedge_quarter[$i],2);
            if ($est_quarter[$i] == 0) {
                $perc_hedge_quarter[$i] = 0;
            } else {
                $perc_hedge_quarter[$i] = ((float)$hedge_quarter[$i] / (float)$est_quarter[$i]) * 100;
            }

            if ($est_quarter[$i] == 0) {
                $perc_open_quarter[$i] = 0;
            } else {
                $perc_open_quarter[$i] = ((float)$open_quarter[$i] / (float)$est_quarter[$i]) * 100;
            }

            if ($hedge_quarter[$i] == 0) {
                $hedge_effective_wap_quarter[$i] = 0;
            } else {
                $hedge_effective_wap_quarter[$i] = (round((float)$hedge_commodity_cost_quarter[$i]) / (float)$hedge_quarter[$i]);
            }
            $unhedge_commodity_cost_quarter[$i] = (float)$unhedge_effective_wap_quarter[$i] * (float)$open_quarter[$i];
            $portfolio_commodity_cost_quarter[$i] = round((float)$hedge_commodity_cost_quarter[$i]) + round((float)$unhedge_commodity_cost_quarter[$i]);
            if ($est_quarter[$i] == 0) {
                $port_effective_price_quarter[$i] = 0;
            } else {
                $port_effective_price_quarter[$i] = round((float)$portfolio_commodity_cost_quarter[$i]) / (float)$est_quarter[$i];
            }
        }
    }
    // echo "estimation";
    // print_r($multy_est);

    ?>
    <ul>
        <div class="sec1art1Wrapper">
            <img src="img/nus-logo-2020.svg" alt="NUS Logo" width="21%" style="margin: 0 0 20px 10px;">
            <br>
            <li> <span>PARENT NAME</span>
                <h2><?php echo  $row_CPR['parentId']; ?></h2>
            </li>
            <li><span>COMMODITY - REPORT PERIOD </span>
                <h2><?php echo  ucwords($row_CPR['commodityName']) . " - " . $year; ?></h2>
            </li>
            <li><span>REPORT CONTRACT CONSUMPTION (MWH)</span>
                <h2><?php echo   number_format($total_est); ?></h2>
            </li>
            <li <?php echo $titleC; ?>><span>COUNTRY - CLIENTS</span>
                <h2><?php echo  $row_CPR['countryName'] . " - " . $client_CPR; ?></h2>
            </li>
            <!-- <li <?php echo $titleC; ?>><span>CLIENTS</span>
            <h2><?php echo $client_CPR; ?></h2>
        </li> -->
            <li><span>CONTRACTS</span>
                <h2><?php echo  $contract_CPR; ?></h2>
            </li>
            <li <?php echo $title; ?>><span>CURRENCY</span>
                <h2><?php echo  $row_CPR['contractpricetype']; ?></h2>
            </li>



        </div>
    </ul>
    <section>
        <article id="container">
            <!-- graph -->
        </article>
        <?php
        if ($_POST['view_CPR'] == "Monthly") {
        ?>
            <article>
                <table class="tableIERCommon" id="tableIERconsolidated">
                    <thead style="border-bottom: 2px solid gray;">
                        <th style="text-align: left;">Consolidated</th>
                        <?php
                        for ($i = 0; $i < count($month1); $i++) {
                        ?>
                            <th><?php echo $month1[$i]; ?></th>
                        <?php
                        }
                        ?>
                        <th>Total</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Est. Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $multy_est[$i]);
                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_est);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", round(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $multy_hed[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Open Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $multy_open[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_open);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>% Hedged</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>


                                <td><?php echo number_format((float)$multy_perchedge[$i], 2) . "%" ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_perc_hedge);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2)) . "%";  ?></td>
                        </tr>
                        <tr style="border-bottom: 2px solid gray;">
                            <td>% Open</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>


                                <td><?php echo number_format((float)$multy_peropen[$i], 2) . "%" ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_perc_open);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2)) . "%";  ?></td>

                        </tr>

                        <tr>
                            <td>Hedged Effective WAP (per MWh)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {

                            ?>
                                <td><?php $strvalue = str_replace(",", "", $hedge_effective_wap[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge_effective_wap);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Unhedged Effective WAP (per MWh)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>

                                <td><?php echo number_format((float)$unhedged_eff_wap[$i], 2) ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_unhedge_effective_wap);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr style="border-bottom: 2px solid gray;">
                            <td>Port Effective Price (Hedged + Unhedged)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td><?php $strvalue = str_replace(",", "", $port_effective_price[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_port_effective_price);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Effective Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td><?php $strvalue = str_replace(",", "", $totaleffective_commodity[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Unhedged Effective Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {

                            ?>
                                <td><?php $strvalue = str_replace(",", "", $unhedge_effective_commodity_cost[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_unhedge_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Est. Portfolio Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {


                            ?>
                                <td><?php $strvalue = str_replace(",", "", $est_Portfolio_Commodity_Cost[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_portfolio_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                    </tbody>
                </table>
            </article>
        <?php
        // } else if(1 === 11) {
        }else{
            // Quarterly
            $quarter = ["Q1", "Q2", "Q3", "Q4"];
        ?>
            <article>
                <table class="tableIERCommon" id="tableIERconsolidated">
                    <thead style="border-bottom: 2px solid gray;">
                        <th style="text-align: left;">Consolidated</th>
                        <?php
                        for ($i = 0; $i < count($quarter); $i++) {
                        ?>
                            <th><?php echo $quarter[$i]; ?></th>
                        <?php
                        }
                        ?>
                        <th>Total</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Est. Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $est_quarter[$i]);
                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                    echo preg_replace($regex, ",", round(((float)$strvalue), 2));  ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"> <?php $strvalue = str_replace(",", "", $total_est);
                                                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                        echo preg_replace($regex, ",", round(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $hedge_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Open Consumption (MWh)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>

                                <td><?php $strvalue = str_replace(",", "", $open_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_open);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>% Hedged</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>


                                <td><?php echo number_format((float)$perc_hedge_quarter[$i], 2) . "%" ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_perc_hedge);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2)) . "%";  ?></td>
                        </tr>
                        <tr style="border-bottom: 2px solid gray;">
                            <td>% Open</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>


                                <td><?php echo number_format((float)$perc_open_quarter[$i], 2) . "%" ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_perc_open);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2)) . "%";  ?></td>

                        </tr>

                        <tr>
                            <td>Hedged Effective WAP (per MWh)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {

                            ?>
                                <td><?php $strvalue = str_replace(",", "", $hedge_effective_wap_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge_effective_wap);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Unhedged Effective WAP (per MWh)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>

                                <td><?php echo number_format((float)$unhedge_effective_wap_quarter[$i], 2) ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_unhedge_effective_wap);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr style="border-bottom: 2px solid gray;">
                            <td>Port Effective Price (Hedged + Unhedged)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td><?php $strvalue = str_replace(",", "", $port_effective_price_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue), 2)); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_port_effective_price);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue), 2));  ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Effective Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td><?php $strvalue = str_replace(",", "", $hedge_commodity_cost_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Unhedged Effective Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {

                            ?>
                                <td><?php $strvalue = str_replace(",", "", $unhedge_commodity_cost_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_unhedge_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                        <tr>
                            <td>Est. Portfolio Commodity Cost</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {


                            ?>
                                <td><?php $strvalue = str_replace(",", "", $portfolio_commodity_cost_quarter[$i]);
                                    echo  preg_replace($regex, ",", number_format(((float)$strvalue))); ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_portfolio_commodity_cost);
                                                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                    echo preg_replace($regex, ",", number_format(((float)$strvalue)));  ?></td>
                        </tr>
                    </tbody>
                </table>
            </article>



        <?php

        } 

        // echo "<h4>Calculation is Under Progress....</h4>"
        ?>
        <!-- <?php
        
        // }
        ?> -->
       
        <article>
            <table class="tableIER" id="myTable" style="width: 80%; font-size:0.85rem;">
                <thead>
                    <th>Contracts Included</th>
                    <th>Country</th>
                    <th>Client</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Supplier</th>
                    <th>Contract Type</th>
                    <th class="lastHeadIER">Contract Annual Consumption</th>

                </thead>
                <tbody>

                    <?php
                    include("dbconn.php");

                    $contract_arr = explode(",", $contracts);
                    // print_r($contract_arr);
                    $sqlQuery3 = "SELECT * FROM nus_supply_contract                  
             INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId
             WHERE supplierId IN ($contracts) ORDER BY nus_supply_contract.contract_id ASC";
                    $result3 = mysqli_query($conn, $sqlQuery3);

                    while ($row_IERmonthly = mysqli_fetch_assoc($result3)) {
                        $sqlValue1[] = $row_IERmonthly;
                    }
                    for ($i = 0; $i < count($contract_arr); $i++) {
                    ?>
                        <tr>
                            <?php

                            ?>

                            <td><?php echo $sqlValue1[$i]['contract_id']; ?></td>
                            <td><?php echo $sqlValue1[$i]['country']; ?></td>
                            <td><?php echo $sqlValue1[$i]['clientcompany']; ?></td>
                            <td><?php $startDate = date_create($sqlValue1[$i]['contractTermfromDate']);
                                echo date_format($startDate, "d-M-Y"); ?></td>
                            <td><?php $endDate = date_create($sqlValue1[$i]['contractTermtoDate']);
                                echo date_format($endDate, "d-M-Y"); ?></td>
                            <td><?php echo $sqlValue1[$i]['supplyName']; ?></td>
                            <td><?php echo ucfirst($sqlValue1[$i]['contractType']); ?></td>
                            <td class="lasttdIER">
                                <?php

                                $totalconsump = str_replace(",", "", $sqlValue1[$i]['totalAnualConsumption']);
                                $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                echo $usdformat = preg_replace($regex, ",", number_format($totalconsump));
                                ?>
                            </td>

                        </tr>
                    <?php
                    } ?>

                </tbody>
            </table>
        </article>
    </section>





</body>
<script>
    <?php
    if ($_POST['view_CPR'] == 'Monthly') {
    ?>

        function drawChart() {

            // Define the chart to be drawn.

            var data = google.visualization.arrayToDataTable([

                ['Month', 'Hedged Consumption', {

                    role: "style"

                }, 'Open Consumption', {

                    role: "style"

                }],

                ["Jan", <?php echo $multy_hed[0]; ?>, "#4472c4", <?php echo $multy_open[0]; ?>, "#BCBCBC"],

                ["Feb", <?php echo $multy_hed[1]; ?>, "#4472c4", <?php echo $multy_open[1]; ?>, "#BCBCBC"],

                ["Mar", <?php echo $multy_hed[2]; ?>, "#4472c4", <?php echo $multy_open[2]; ?>, "#BCBCBC"],

                ["Apr", <?php echo $multy_hed[3]; ?>, "#4472c4", <?php echo $multy_open[3]; ?>, "#BCBCBC"],

                ["May", <?php echo $multy_hed[4]; ?>, "#4472c4", <?php echo $multy_open[4]; ?>, "#BCBCBC"],

                ["Jun", <?php echo $multy_hed[5]; ?>, "#4472c4", <?php echo $multy_open[5]; ?>, "#BCBCBC"],

                ["Jul", <?php echo $multy_hed[6]; ?>, "#4472c4", <?php echo $multy_open[6]; ?>, "#BCBCBC"],

                ["Aug", <?php echo $multy_hed[7]; ?>, "#4472c4", <?php echo $multy_open[7]; ?>, "#BCBCBC"],

                ["Sep", <?php echo $multy_hed[8]; ?>, "#4472c4", <?php echo $multy_open[8]; ?>, "#BCBCBC"],

                ["Oct", <?php echo $multy_hed[9]; ?>, "#4472c4", <?php echo $multy_open[9]; ?>, "#BCBCBC"],

                ["Nov", <?php echo $multy_hed[10]; ?>, "#4472c4", <?php echo $multy_open[10]; ?>, "#BCBCBC"],

                ["Dec", <?php echo $multy_hed[11]; ?>, "#4472c4", <?php echo $multy_open[11]; ?>, "#BCBCBC"]


            ]);



            var options = {

                title: 'Hedged Consumption Chart (Consumption in MWh)',

                subtitle: 'Consumption in MWh',

                isStacked: true,

                legend: {

                    position: 'bottom'

                },

                colors: ['#4472c4', '#bcbcbc'],
                width: 1200,
                height: 400,
                backgroundColor: {
                    fill: 'transparent'
                },
                // vertical = vAxis & horizontal = hAxis
                bar: {
                    groupWidth: "50%"
                },
                legend: {
                    position: "bottom"
                },
                // vAxis: {format:'#.# %'}, 
                // vAxis: {
                //     gridlines: {
                //         count: 10
                //     },}

            };



            // Instantiate and draw the chart.

            var chart = new google.visualization.ColumnChart(document.getElementById('container'));

            chart.draw(data, options);

            // console.log('Intel inside');

        }

        google.charts.setOnLoadCallback(drawChart);
    <?php
    } else{
        // Quarterly chart
    ?>

        function drawChart() {

            // Define the chart to be drawn.

            var data = google.visualization.arrayToDataTable([

                ['Month', 'Hedged Consumption', {

                    role: "style"

                }, 'Open Consumption', {

                    role: "style"

                }],

                ["Q1", <?php echo $hedge_quarter[0]; ?>, "#4472c4", <?php echo $open_quarter[0]; ?>, "#BCBCBC"],

                ["Q2", <?php echo $hedge_quarter[1]; ?>, "#4472c4", <?php echo $open_quarter[1]; ?>, "#BCBCBC"],

                ["Q3", <?php echo $hedge_quarter[2]; ?>, "#4472c4", <?php echo $open_quarter[2]; ?>, "#BCBCBC"],

                ["Q4", <?php echo $hedge_quarter[3]; ?>, "#4472c4", <?php echo $open_quarter[3]; ?>, "#BCBCBC"],



            ]);



            var options = {

                title: 'Monthly-Contracts Position Chart',

                subtitle: 'Consumption in MWh',

                isStacked: true,

                legend: {

                    position: 'bottom'

                },

                colors: ['#4472c4', '#bcbcbc'],
                width: 1200,
                height: 400,
                backgroundColor: {
                    fill: 'transparent'
                },
                // vertical = vAxis & horizontal = hAxis
                bar: {
                    groupWidth: "50%"
                },
                legend: {
                    position: "bottom"
                },
                // vAxis: {format:'#.# %'}, 
                // vAxis: {
                //     gridlines: {
                //         count: 10
                //     },}

            };



            // Instantiate and draw the chart.

            var chart = new google.visualization.ColumnChart(document.getElementById('container'));

            chart.draw(data, options);

            // console.log('Intel inside');

        }

        google.charts.setOnLoadCallback(drawChart);


    <?php
    }
    ?>
</script>

 <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script> -->
    <!-- <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script> -->
    <script src="common_files/jquery_min_3.6.0.js"></script>
    <script src="common_files/jquery_datatable_min_1.12.2.js"></script>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>

</html>