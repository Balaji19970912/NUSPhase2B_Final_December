<?php
include '../dbconn.php';
session_start();
$resCountry ='';


if($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    $activeStatus = "AND state = 'Active'";
} else {
    $activeStatus = "";
}

if (isset($_POST['country_CPR'])) {
    $resCountry = $_POST['country_CPR'];
    // echo "<script>alert($resCountry);</script>";
}
if(empty($_SESSION['client'])) {
    $getdatas = "SELECT * FROM clientcompanydata WHERE  country = '".$resCountry."'  AND parentcompany = '".$_POST['parentID']."' ".$activeStatus."  AND state = 'Active' 
    ORDER BY clientcompany  ASC;";


}
else{
    echo "1";
    $getdatas = "SELECT * FROM clientcompanydata WHERE  country = '".$resCountry."'  AND parentcompany = '".trim($_POST['parentID'])."' ".$activeStatus."  AND state = 'Active' 
    ORDER BY clientcompany  ASC;";    // echo $getdatas;
}
// $result = $conn->query($getdatas);
// echo $getdatas;
$selectAll = '<li><input type="checkbox"  onchange ="getClientCPR(this.value)" value="selectALL" id="selectAllClientCPR" onclick="selectAllClientsCPR()"><label for="selectAllClientCPR" id="labelSelectAll">Select All</label></li>';
$displayValue1 = '';
    // $sqlClient = "SELECT * FROM clientcompanydata WHERE  country IN ($trimCoun) AND parentcompany = '".$_POST['parentId']."' ".$activeStatus."  ORDER BY clientcompany  ASC;";
    $resClient = $conn->query($getdatas);
    $client = array();
    if ($resClient->num_rows > 0) {
        while ($rowClient = mysqli_fetch_assoc($resClient)) {
            $client[] = $rowClient;
        }
    }
    foreach ($client as $resClient) {
        $displayValue1 .= '<li><input type="checkbox" id="' . $resClient["id"] . '" class="clientCountryCPR" value="' . $resClient["id"] . '" name="clientcheckbox_CPR[]"  onchange="getClientCPR(this.value)"><label for="' . $resClient["id"] . '">' . $resClient["clientcompany"] . ' </label></li>';
    }

    echo $selectAll.$displayValue1;
