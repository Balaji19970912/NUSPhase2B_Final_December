<?php
include "../dbconn.php";


$contract = $_POST['contractID'];
$contract_arr = explode(',',$contract);
$contract_arr = array_unique($contract_arr);
$contract = implode(',',$contract_arr);
if($contract == ''){
  $contract = 0;
}
// echo "<script>alert('$contract');</script>";

// $contract = '1,2,24,47';
// $sqlQuery5 = "SELECT * FROM nus_supply_contract WHERE supplierId = '".$_POST['contractID']."';";
$sqlQuery5 = "SELECT * FROM nus_supply_contract WHERE supplierId IN ($contract) ;";
// echo $sqlQuery5;
$year=[];
$strYear=[];
$uniqueyear=array();
$strYear1=array(array());
// $strYear = "";
$result5 = mysqli_query($conn,$sqlQuery5);
$i=0;
while($yearRow = mysqli_fetch_assoc($result5)){
    $year[$i] = $yearRow['allmonts']; 
    $strYear[$i] = explode(',' ,$year[$i]);
    
  $i++;
}
$contractarry = explode(",",$contract);
// print_r($strYear[0]);
// echo count($strYear[2]);
// $k=0;
if($contract != 0){
for($i=0;$i<count($contractarry);$i++){
  
  for($j=0;$j<count($strYear[$i]);$j++){
    $strYear1[$i][$j] = explode('-',$strYear[$i][$j]);
    if(!in_array($strYear1[$i][$j][0],$uniqueyear))
    $uniqueyear[] = $strYear1[$i][$j][0];
    // $K++;
  }
}
}

sort($uniqueyear);
$displayYear='';

foreach($uniqueyear as $yearValues){

// $displayYear .='<div class="values"><label><input type="radio" value="'.$yearValues.'" name="yearMultiple" id="'.$yearValues.'" class="yearMultiple" onclick="yearCheck()">'.$yearValues.'</label></div>';
// $displayYear .= '<div class="cat action"><label><input type="radio" value="' . $yearValues . '" name="yearMultiple" id="' . $yearValues . '"  onclick="yearCheck()"></label><span class="disabledbutton act">' . $yearValues . '</span></div>';
$displayYear  .='<div class="cat action">
<label>
   <input type="radio" value="'.$yearValues.'" name="yearstype[]" class="contactType" 
    ><span class="disabledbutton dis">'.$yearValues.'</span>
</label>
</div>';

}
// $printdata .='</div>';
print_r($displayYear);



?>
