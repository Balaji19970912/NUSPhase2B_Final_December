<?php
include "../dbconn.php";
session_start();
$valueReport = '';
if ($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    // $activeStatus = "AND state = 'Active'";
    $activeStatus = "AND nus_supply_contract.state = 'Active'";
} else {
    $activeStatus = "";
}
// $country = '';
$clients ='';
if(isset($_POST['clientID'])){
    foreach($_POST['clientID'] as $values ){
        $clients .= $values . ",";
    }
}
$trimClient = trim($clients, ','); // client id values are stored
if ($trimClient == '') {
    $trimClient = 0;
}

// echo $_POST['commodity'];
if (empty($_SESSION['client'])) {
    $getdatas = "SELECT * FROM nus_supply_contract 
    INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
    WHERE clientId IN ($trimClient) 
    AND commodityName = '" . $_POST['commodity'] . "' " . $activeStatus . " AND nus_supply_contract.state = 'Active' AND country = '".$_POST['countrySingleCPR']."' AND contractType='indexed'
    ORDER BY nus_supply_contract.contract_id ASC;";
} else {
    $getdatas = "SELECT * FROM nus_supply_contract 
    INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
    WHERE clientId IN ($trimClient) 
    AND commodityName = '" . $_POST['commodity'] . "' " . $activeStatus . " AND nus_supply_contract.state = 'Active' AND country = '".$_POST['countrySingleCPR']."' AND contractType='indexed'
    ORDER BY nus_supply_contract.contract_id ASC;";
  
}

// echo $getdatas;
// $result = $conn->query($getdatas);  

// select ALL code
$selectAll = '<li><input type="checkbox" onchange=contractsyearCPR(this.value) value="selectALL" id="selectAllContracts" onclick="selectAllContract()"><label for="selectAllContracts" id="labelSelectAll">Select All</label></li>';

    $result5 = mysqli_query($conn, $getdatas);
    $contracts = array();
    $contractsDisplay = '';
    if ($result5->num_rows > 0) {
        while ($rowContracts = mysqli_fetch_assoc($result5)) {
            $contracts[] = $rowContracts;
        }
    }
    foreach ($contracts as $rowContracts) {
        $startDate = date_create($rowContracts['contractTermfromDate']);
        $startDate =  date_format($startDate, "d-M-Y");
        $contractsDisplay .= '<li><input type="checkbox" id="supplier' . $rowContracts["supplierId"] . '"  class="contractscheckbox" value="' . $rowContracts["supplierId"] . '" name="contractcheckbox_CPR[]"  onclick=contractsyearCPR(this.value) ><label for="supplier' . $rowContracts["supplierId"] . '">' . $rowContracts["clientcompany"] . ' - ' . $rowContracts["contract_id"] . ' - ' . $startDate . '</label></li>';

        // $contractsDisplay .= '<li><input type="checkbox" id="supplier' . $rowContracts["supplierId"] . '"  class="contractscheckbox" value="' . $rowContracts["supplierId"] . '" name="contractcheckbox_CPR[]"  onclick=contractsyearCPR(this.value) ><label for="supplier' . $rowContracts["supplierId"] . '">' . $rowContracts["clientcompany"] . ' - ' . $rowContracts["contract_id"] . ' - ' . $rowContracts["countryName"] . ' - ' . $startDate . '</label></li>';
    }

    echo $selectAll . $contractsDisplay;



?>