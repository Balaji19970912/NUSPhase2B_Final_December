<?php
 echo "<script type='text/javascript'>
 const el = document.getElementsByClassName('hovergenerateReport');
 el[0].style.fontWeight = '700';
 el[0].style.color = '#12263f';
 el[0].style.background = 'url(img/generate-report-hover-icon.svg) no-repeat';
 el[0].style.backgroundPosition = 'left';
 el[0].style.borderRight='5px solid blue';
 </script>";

?>