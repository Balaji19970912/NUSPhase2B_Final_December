function reporttype(argument) {
  if (argument == "single") {
    $(".single").show();
    $(".multi").hide();
    $(".international").hide();
    $(".tradehistroy").hide();
    $(".rpoe").addClass("col-md-12");
    $(".rpoe").removeClass("col-md-6");
    $(".multcon").hide();
    $(".reprttype").hide();
  }
  if (argument == "multi") {
    $(".single").hide();
    $(".multi").show();
    $(".international").hide();
    $(".tradehistroy").hide();
    $(".multcon").show();
    $(".reprttype").hide();
    $(".rpoe").addClass("col-md-12");
    // $(".rpoe").addClass("col-md-6");
    $(".multcon").hide();
   
  }
  if (argument == "international") {
    $(".single").hide();
    $(".multi").hide();
    $(".international").show();
    $(".tradehistroy").hide();
    //new class add here
    // $("#parentIER").addClass("col-md-12");
    // $("#clientIER").addClass("col-md-12");
    // $(".selectCountry").addClass("col-md-12");

    $(".reprttype").hide();
    $(".multcon").hide();
    // $(".rpoe").removeClass("col-md-12");

    // $('.rpoe').addClass('col-md-6');
    // $(".rpoe").addClass("col-md-12");
  }
  if (argument == "tradehistry") {
    $(".single").hide();
    $(".multi").hide();
    $(".international").hide();
    $(".tradehistroy").show();
    $(".multcon").hide();
    $(".reprttype").hide();
    $(".rpoe").addClass("col-md-12");
    // $('.rpoe').removeClass('col-md-6');
    // $('.rpoe').removeClass('col-md-12');
  }
}
function addclient() {
  var rowVal = parseInt($(".rowclient").val()) + 1;
  var printdata = "";
  printdata = '<div class="row">';
  printdata += '<div class="col-md-5">';
  printdata +=
    '<select name="client' +
    rowVal +
    '" onchange="getallsupplycontract(this.value)" class="form-control client' +
    rowVal +
    '">';
  printdata += "</select>";
  printdata += "</div>";
  printdata += '<div class="col-md-5">';
  printdata += '<div class="multse">';
  printdata +=
    '<select id="framework' +
    rowVal +
    '" name="framework[]" multiple class="form-control">';
  printdata += "</div></div></div>";
  $(".addedclient").append(printdata);
  $(".client" + rowVal + "").html($(".listclients").html());
  // $('.listclients').find('option').clone().appendTo('.client'+rowVal+'');
  rowVal = rowVal;
  $(".rowclient").val(rowVal);
}
function addcountries() {
  var rowVal = parseInt($(".rowcountries").val()) + 1;
  var printdata = "";
  printdata = '<div class="row">';
  printdata += '<div class="col-md-5">';
  printdata +=
    '<select name="country' +
    rowVal +
    '" onchange="getsupplycontractcounty(this.value)" class="form-control countryval' +
    rowVal +
    '">';
  printdata += "</select>";
  printdata += "</div>";
  printdata += '<div class="col-md-5">';
  printdata += '<div class="multse">';
  printdata +=
    '<select id="countyr' +
    rowVal +
    '" name="framework[]" multiple class="form-control">';
  printdata += "</div></div></div>";
  $(".addedcountry").append(printdata);
  $(".countryval" + rowVal + "").html($(".listcountries").html());
  // $('.listclients').find('option').clone().appendTo('.client'+rowVal+'');
  rowVal = rowVal;
  $(".rowcountries").val(rowVal);
}
function getclientfromcountry(val) {
  var getCommodity = $(".commodityreport:checked").val();
  var countryname = val;
  $.ajax({
    url: "ajax/getclientcountry.php",
    type: "POST",
    data: {
      commodity: getCommodity,
      countryname: countryname,
    },
    success: function (result) {
      console.log(result);
      $(".listclients").html(result);
    },
  });
}
function getallsupplycontract(value) {
  var getCommodity = $(".commodityreport:checked").val();
  var county = $(".countries").val();
  var rocnt = parseInt($(".rowclient").val());

  $.ajax({
    url: "ajax/getallclients.php",
    type: "POST",
    data: {
      commodity: getCommodity,
      countryname: county,
      client: value,
    },
    success: function (result) {
      console.log(rocnt);
      $("#framework" + rocnt).html(result);
      $("#framework" + rocnt).multiselect({
        nonSelectedText: "Select Contract",
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth: "300px",
      });
    },
  });
}
function getsupplycontractcounty(val) {
  var getCommodity = $(".comdityinter:checked").val();
  var parent = $(".paret").val();
  var rocnt = parseInt($(".rowcountries").val());

  $.ajax({
    url: "ajax/getallcountryclients.php",
    type: "POST",
    data: {
      commodity: getCommodity,
      parent: parent,
      country: val,
    },
    success: function (result) {
      console.log(result);
      $("#countyr" + rocnt).html(result);
      $("#countyr" + rocnt).multiselect({
        nonSelectedText: "Select Country",
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth: "300px",
      });
    },
  });
}

function contractTermchange(contract) {
  // alert(contract);
  
  $.ajax({
    url: "ajax/getContractTerm.php",
    type: "POST",
    data: {
      contract: contract,
    },
    success: function (result) {
      var obj = JSON.parse(result);
      $(".indexcnt").html(obj.indexData);
      $(".fixcnt").html(obj.fixedData);
    },
  });
}
function clientChange(val) {
  console.log(val);
  $.ajax({
    url: "ajax/getreport.php",
    type: "POST",
    data: {
      country_data: val,
    },
    success: function (result) {
      $("#contract").html(result);

      // console.log(result);
    },
  });
}

function parentdetails(parentId) {
  $.ajax({
    type: "POST",
    url: "js/callbacks/parentdetails.php",
    data: {
      parentId: parentId,
    },
    success: function (data) {
      $(".clientcom").html(data);
    },
  });
}

function parentdetails_GenerateReport(parentId) {
  // alert(1);
  $.ajax({
    type: "POST",
    url: "js/callbacks/parentdetailsGenReport.php",
    data: {
      parentId: parentId,
    },
    success: function (data) {
      $(".clientcom").html(data);
    },
  });
}

// function parentdetails_GenerateReportIER(parentId) {
//   $.ajax({
//     type: "POST",
//     url: "js/callbacks/parentdetailsGenReportIER.php",
//     data: {
//       parentId: parentId,
//     },
//     success: function (data) {
//       $(".multiCountrySelectIER").html(data),
//         $("#multiCountryIER").multiselect({
//           columns: 1,
//           placeholder: "Select one or more Country",
//           search: true,
//           selectAll: true
//         });
//     },
//   });
// }

function clientChange(val) {
  console.log(val);
  $.ajax({
    url: "ajax/getfixedreport.php",
    type: "POST",
    data: {
      countrydata: val,
    },
    success: function (result) {
      $("#fixedcontract").html(result);

      // console.log(result);
    },
  });
}
function getcontract(clinet) {
  $.ajax({
    url: "ajax/gettradecontract.php",
    type: "POST",
    data: {
      client: clinet,
    },
    success: function (result) {
      console.log(result);
      $(".tradecontract").html(result);
    },
  });
}

// International Report function starts here
function parentdetails_GenerateReportIER(parentId) {
  // alert(parentId);
  let reportType = $("#reportdatas").val();
  if (reportType == "Country Position Report") {
    $.ajax({
      url: "ajax/countrydispaly_2B.php",
      method: "POST",
      data: {
        values: parentId,
        valueReport: reportType,
      },
      success: function (data) {
        $("#countries").html(data);
      },
    });
  } else {
    $.ajax({
      url: "ajax/countrydispalyIER.php",
      method: "POST",
      data: {
        parentId: parentId,
        valueReport: reportType,
      },
      success: function (data) {
        $("#countryMulti").html(data);
      },
    });
  }
}

var displayCountry = "";
function multiCountries(countryVals) {
  // console.log(countryVals);
  let countryArr = [];
  let totalCountryChilds = document.querySelectorAll(".countryD").length;
  let countries = document.querySelectorAll(".countryD:checked");
  let countryLabelV = []
  let countryValue = document.querySelector('.countryD:checked');
  // console.log(clientsValue);
  if(countryValue == null){
  console.log("hello");
  }
  else{
  console.log("false");
  countryValue.labels.forEach((item)=>countryLabelV.push(item.textContent));
  }
  console.log(countryLabelV[0]);

  for (let i = 0; i < countries.length; i++) {
    countryArr.push(countries[i].value);
  }
  console.log(countryArr);
  // console.log('Array legth ==>', countryArr.length);
  if (countryArr.length == 0) {
    $(".multipleCountry").prop("placeholder", "Select Country");
  } else if (countryArr.length == 1) {
    $(".multipleCountry").prop(
      "placeholder",
      countryLabelV[0]
      // "placeholder", countryArr,
      // "Selected " + countryArr.length + " Country"
    );
    $('#resCountriesIER').val(countryLabelV[0]);
  } else if (countryArr.length > 1) {
    $(".multipleCountry").prop(
      "placeholder",
      "Selected " + countryArr.length + " Countries"
    );
    $('#resCountriesIER').val('Multiple');
  }

  if (totalCountryChilds == countryArr.length) {
    $("#selectAllChkbox").prop("checked", true);
    $(".multipleCountry").prop("placeholder", "Selected All");
    $('#resCountriesIER').val("All");
  } else {
    $("#selectAllChkbox").prop("checked", false);
  }
  if(totalCountryChilds == 1 && countryArr.length == 1){
    $(".multipleCountry").prop(
      // "placeholder", countryArr,
      "placeholder",
      countryLabelV[0]
    )
    $('#resCountriesIER').val(countryLabelV[0]);
  }
//  else if(countryArr.length == 0){
//   $(".multipleCountry").prop("placeholder", "Select Country");
//  }
  let reportType = $("#reportdatas").val();
  let parentVal = $("#parentIER").val();
  // let commodityV = $('.commoditys').val();
  $.ajax({
    url: "ajax/clientMultiIER.php",
    method: "POST",
    data: {
      countries: countryArr,
      parentId: parentVal,
      // 'commodity': commodityV,
      valueReport: reportType,
    },
    success: function (data) {
      $("#mclients").html(data);
    },
  });
}

let clientId = "";

function multiClients(clientsId) {
  // let count ='';
  console.log(clientsId);
  let clientArr = [];
  let clientCountry = document.querySelectorAll(".clientCountry:checked");
  let totalClientChilds = document.querySelectorAll(".clientCountry").length;
  console.log("totalClient===>" +totalClientChilds);
  let clientLabelV = []
  let clientsValue = document.querySelector('.clientCountry:checked');
  console.log(clientsValue);
  if(clientsValue == null){
  console.log("hello");
  }
  else{
  console.log("false");
  clientsValue.labels.forEach((item)=>clientLabelV.push(item.textContent));
  }
 
  // var clientsValue = document.querySelector('.clientCountry:checked').labels.forEach((item)=>clientLabelV.push(item.textContent));
  console.log(clientLabelV[0]);
  // if(clientLabelV[0] < 1){
  //   alert("1");
  // }
  // console.log(clientCountry);
  for (let i = 0; i < clientCountry.length; i++) {
    clientArr.push(clientCountry[i].value);
  }
  console.log(clientArr);
  console.log('Array legth ==>', clientArr.length)
  if (clientArr.length == 0) {
    $(".multipleClients").prop("placeholder", "Select Client");
  } else if (clientArr.length == 1) {
    $(".multipleClients").prop(
      "placeholder",
      clientLabelV[0]
      // "Selected " + clientArr.length + " Client"
    )
    $('#result').val( clientLabelV[0]);
  } else if (clientArr.length > 1) {
    $(".multipleClients").prop(
      "placeholder",
      "Selected " + clientArr.length + " Clients"
    );
    $('#result').val('Multiple');
  }

  if (totalClientChilds == clientArr.length) {
    $("#selectAllClients").prop("checked", true);
    $(".multipleClients").prop("placeholder", "Selected All");
    $('#result').val('All');
  } else {
    $("#selectAllClients").prop("checked", false);
  }
 
  if(totalClientChilds == 1 && clientArr.length == 1){
    $(".multipleClients").prop(
      "placeholder",
      clientLabelV[0]
    )
    $('#result').val( clientLabelV[0]);
  }

  let reportType = $("#reportdatas").val();
  let parentVal = $("#parentIER").val();
  let commodityV = $(".commodityreport:checked").val();
  console.log(commodityV);
  console.log(clientArr);

  $.ajax({
    url: "ajax/contractsIER.php",
    method: "POST",
    data: {
      clientID: clientArr,
      parerntC: parentVal,
      commodity: commodityV,
      valueReport: reportType,
    },
    success: function (data) {
      $("#MultipleContracts").html(data);
    },
  });
}

function selectClient(commodity) {
  // alert(1);
  // alert(commodity);
  let commodityV = commodity;
  $("#reportdatas").css("pointer-events", "none");
  $("#parentIER").css("pointer-events", "none");
  $("#multiCountry").css("pointer-events", "none");
  // if ($('.commoditys:checked').val() == 'electricity') {
  //     commodityV = 'electricity';
  // } else {
  //     commodityV = 'natural gas';
  // }
  // let commodityV = $('.commoditys').val();

  let countryV = $("#countries").val();
  let parentVal = $("#parentIER").val();
  // let clientId = $('#client_company').val();
  let clientArr = [];
  let clientCountry = document.querySelectorAll(".clientCountry:checked");
  console.log(clientCountry);
  for (let i = 0; i < clientCountry.length; i++) {
    clientArr.push(clientCountry[i].value);
  }
  $.ajax({
    url: "ajax/contractsIER.php",
    method: "POST",
    data: {
      parerntC: parentVal,
      commodity: commodityV,
      // 'country': countryV,
      clientID: clientArr,
    },
    success: function (data) {
      $("#MultipleContracts").html(data);
    },
  });
}

function displayClients() {
  $("#reportdatas").css("pointer-events", "none");
  $("#parent_company").css("pointer-events", "none");
  $("#multiCountry").css("pointer-events", "none");
  let cleints = document.getElementById("mclients");
  if (cleints.style.display == "none") {
    // alert(contracts);
    cleints.style.display = "block";
  } else {
    // alert('22');
    cleints.style.display = "none";
  }
}

function contractsyear(contractsID) {
  let contract = [];
  let tempArr = [];
  let contracts = document.querySelectorAll(".contractscheckbox:checked");
  console.log( "result==>"+contracts.innerHTML);
  let totalContractsChild = document.querySelectorAll(".contractscheckbox").length;
  let labelContractsV = []
  let contractsLabel = document.querySelector('.contractscheckbox:checked');
  

// var contractsLabel = document.querySelector('.contractscheckbox:checked').labels.forEach((item)=>labelContractsV.push(item.textContent));
// console.log(labelContractsV[0]);

  // console.log(contracts);
  
  if(contractsLabel == null){
    console.log("hello");
    }
    else{
    console.log("false");
    contractsLabel.labels.forEach((item)=>labelContractsV.push(item.textContent));
    }
  for (var i = 0; i < contracts.length; i++) {
    contract = contract + "," + contracts[i].value;
    tempArr.push(contract[i].value);
  }
  console.log(contract);
  let x  =  document.getElementById("yearsDisplayed");
  let y = document.getElementById("labels");
  if(contract == ''){
    x.style.display = "none";
    document.getElementById("labels").style.display = "none";
  }
  else{
    document.getElementById("labels").style.display = "block";
    x.style.display = "block";
  }
  console.log("Length===>", tempArr.length);
  if (tempArr.length == 0) {
    // alert("1");
    $(".multipleContracts").prop("placeholder", "Select Contract");
    // $("#yearsDisplayed").css("display", "block");
  } else if (tempArr.length == 1) {
    $(".multipleContracts").prop(
      "placeholder",
      labelContractsV[0]
      // "Selected " + tempArr.length + " Contract"
    );
    $('#resultContracts').val( labelContractsV[0]);
  } else if (tempArr.length > 1) {
    $(".multipleContracts").prop(
      "placeholder",
      "Selected " + tempArr.length + " Contracts"
    );
    $('#resultContracts').val('Multiple');
  }

  if (totalContractsChild == tempArr.length) {
    $("#selectAllContracts").prop("checked", true);
    $(".multipleContracts").prop("placeholder", "Selected All");
    $('#resultContracts').val('All');
   
  } else {
    
    
    $("#selectAllContracts").prop("checked", false);
  }
  if(totalContractsChild == 1 && tempArr.length == 1){
    $(".multipleContracts").prop(
      "placeholder",
      labelContractsV[0]
    )
    $('#resultContracts').val( labelContractsV[0]);
  }

  if (contract[0] == ",") {
    contract = contract.slice(1);
  }
  // if ($().is(":checked")){
  //     alert("hi");
  // }
  $.ajax({
    url: "ajax/contractYearIER.php",
    method: "POST",
    data: {
      contractID: contract,
    },
    success: function (data) {
      $("#yearsDisplayed").html(data);
    },
  });


  viewCheckbox();
}
function viewCheckbox() {
  let view = document.querySelectorAll(".view:checked");
  document.getElementById("displayReportPeriod").style.display = "block";
}

// function yearCheck() {
//   $(".values").on("click", function () {
    // $('input[type="checkbox"].yearMultiple').on("change", function () {
      // $('input[type="checkbox"].yearMultiple').not(this).prop("checked", false);
      // alert('I got clicked!');
    // });
//   });
// }
