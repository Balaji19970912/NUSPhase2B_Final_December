function parentdetails_GenerateReportCPR(parentCPR) {
  // alert(parentCPR);
  let parentval = $("#parentCPR").val();
  let reportType = $("#report_type").val();
  // if (reportType == 'Country Position Report') {
  $.ajax({
    url: "ajax/countrydispaly_CPR.php",
    method: "POST",
    data: {
      parentID: parentval,
      // 'valueReport': reportType
    },
    success: function (data) {
      $("#countries_CPR").html(data);
    },
  });
}
// }

function getclientfromcountry(countryCPR) {
  // alert(countryCPR);
  let parentval = $("#parentCPR").val();
  $.ajax({
    url: "ajax/clientMulti_CPR.php",
    method: "POST",
    data: {
      parentID: parentval,
      country_CPR: countryCPR,
    },
    success: function (data) {
      $("#clients_CPR").html(data);
    },
  });
}

function getClientCPR(clientsCPR) {
  console.log(clientsCPR);
  let clientArr = [];
  let selectSIngleCountry = document.getElementById("countries_CPR").value;
  let clientCountryCPR = document.querySelectorAll(".clientCountryCPR:checked");
  console.log(clientCountryCPR);
  let totalClientChilds = document.querySelectorAll(".clientCountryCPR").length;
  // console.log("totalClient===>" +totalClientChilds);
  let clientLabelV = [];
  let clientsValue = document.querySelector(".clientCountryCPR:checked");
  // console.log(clientsValue);
  if (clientsValue == null) {
    // console.log("hello");
  } else {
    // console.log("false");
    clientsValue.labels.forEach((item) => clientLabelV.push(item.textContent));
  }
  // var clientsValue = document.querySelector('.clientCountry:checked').labels.forEach((item)=>clientLabelV.push(item.textContent));
  console.log(clientLabelV[0]);
  for (let i = 0; i < clientCountryCPR.length; i++) {
    clientArr.push(clientCountryCPR[i].value);
  }
  // console.log(clientArr);
  // console.log('Array legth ==>', clientArr.length)
  if (clientArr.length == 0) {
    $(".multiple_Clients_CPR").prop("placeholder", "Select Client");
  } else if (clientArr.length == 1) {
    $(".multiple_Clients_CPR").prop(
      "placeholder",
      clientLabelV[0]
      // "Selected " + clientArr.length + " Client"
    );
    $("#resultClient_CPR").val(clientLabelV[0]);
  } else if (clientArr.length > 1) {
    $(".multiple_Clients_CPR").prop(
      "placeholder",
      "Selected " + clientArr.length + " Clients"
    );
    $("#resultClient_CPR").val("Multiple");
  }
  if (totalClientChilds == clientArr.length) {
    $("#selectAllClientCPR").prop("checked", true);
    $(".multiple_Clients_CPR").prop("placeholder", "Selected All");
    $("#resultClient_CPR").val("All");
  } else {
    $("#selectAllClientCPR").prop("checked", false);
  }
  if (totalClientChilds == 1 && clientArr.length == 1) {
    $(".multiple_Clients_CPR").prop("placeholder", clientLabelV[0]);
    $("#resultClient_CPR").val(clientLabelV[0]);
  }
  let parentVal = $("#parentCPR").val();
  let commodityV = $(".commodityreport:checked").val();
  // alert(commodityV);
  $.ajax({
    url: "ajax/contracts_CPR.php",
    method: "POST",
    data: {
      clientID: clientArr,
      parerntC: parentVal,
      commodity: commodityV,
      countrySingleCPR: selectSIngleCountry,
      // valueReport: reportType,
    },
    success: function (data) {
      $("#contarcts_display_CPR").html(data);
    },
  });
}

function selectCommodity_CPR(commodity) {
  // alert(commodity);
  $("#reportdatas").css("pointer-events", "none");
  $("#parentCPR").css("pointer-events", "none");
  $("#countries_CPR").css("pointer-events", "none");
  // if ($('.commoditys:checked').val() == 'electricity') {
  //     commodityV = 'electricity';
  // } else {
  //     commodityV = 'natural gas';
  // }
  // let commodityV = $('.commoditys').val();

  let selectSIngleCountry = document.getElementById("countries_CPR").value;
  // alert(selectSIngleCountry);
  let parentVal = $("#parentCPR").val();
  let clientArr = [];
  let clientCountryCPR = document.querySelectorAll(".clientCountryCPR:checked");
  // console.log(clientCountryCPR);
  for (let i = 0; i < clientCountryCPR.length; i++) {
    clientArr.push(clientCountryCPR[i].value);
  }
  $.ajax({
    url: "ajax/contracts_CPR.php",
    method: "POST",
    data: {
      parerntC: parentVal,
      commodity: commodity,
      countrySingleCPR: selectSIngleCountry,
      clientID: clientArr,
    },
    success: function (data) {
      $("#contarcts_display_CPR").html(data);
    },
  });
}

function contractsyearCPR(contractsID) {
  let contract = [];
  let tempArr = [];
  let contracts = document.querySelectorAll(".contractscheckbox:checked");
  console.log("result==>" + contracts.innerHTML);
  let totalContractsChild =
    document.querySelectorAll(".contractscheckbox").length;
  let labelContractsV = [];
  let contractsLabel = document.querySelector(".contractscheckbox:checked");
  // var contractsLabel = document.querySelector('.contractscheckbox:checked').labels.forEach((item)=>labelContractsV.push(item.textContent));
  // console.log(labelContractsV[0]);

  // console.log(contracts);

  if (contractsLabel == null) {
    console.log("hello");
  } else {
    console.log("false");
    contractsLabel.labels.forEach((item) =>
      labelContractsV.push(item.textContent)
    );
  }
  for (var i = 0; i < contracts.length; i++) {
    contract = contract + "," + contracts[i].value;
    tempArr.push(contract[i].value);
  }
 
  // when contract is unchecked report and unhedgeEffec value display none
  let x = document.getElementById("display_CPR_year");
  let unhedge = document.getElementById("unhedge_effective_block");
  // display block none
  if (contract == "") {
    document.getElementById("display_CPR_year").style.display = "none";
    unhedge.style.display="none";
    document.getElementById("labels_CPR").style.display = "none";
  } else {
    document.getElementById("labels_CPR").style.display = "block";
    document.getElementById("display_CPR_year").style.display = "block";
  }

  if (tempArr.length == 0) {
    // alert("1");
    $(".multipleContracts").prop("placeholder", "Select Contract");
    // $("#yearsDisplayed").css("display", "block");
  } else if (tempArr.length == 1) {
    $(".multipleContracts").prop(
      "placeholder",
      labelContractsV[0]
      // "Selected " + tempArr.length + " Contract"
    );
    $("#resultContracts_CPR").val(labelContractsV[0]);
  } else if (tempArr.length > 1) {
    $(".multipleContracts").prop(
      "placeholder",
      "Selected " + tempArr.length + " Contracts"
    );
    $("#resultContracts_CPR").val("Multiple");
  }

  if (totalContractsChild == tempArr.length) {
    $("#selectAllContracts").prop("checked", true);
    $(".multipleContracts").prop("placeholder", "Selected All");
    $("#resultContracts_CPR").val("All");
  } else {
    $("#selectAllContracts").prop("checked", false);
  }
  if (totalContractsChild == 1 && tempArr.length == 1) {
    $(".multipleContracts").prop("placeholder", labelContractsV[0]);
    $("#resultContracts_CPR").val(labelContractsV[0]);
  }
  if (contract[0] == ",") {
    contract = contract.slice(1);
  }

  $.ajax({
    url: "ajax/contractYear_CPR.php",
    method: "POST",
    data: {
      contractID: contract,
    },
    success: function (data) {
      $("#display_CPR_year").html(data);
    },
  });

  viewCheckbox_CPR();
  // display_unhedge();
}
function viewCheckbox_CPR() {
  let view = document.querySelectorAll(".view:checked");
  document.getElementById("displayReportPeriod_CPR").style.display = "block";
}

// format number with comma decimal point 
function unhedgeEffec(inputId) {
  let clicksInput = document.getElementById("hedgevalmon" + inputId + "");
  console.log(clicksInput);
  let unhedgeValue = clicksInput.value.replace(/[^0-9.]/g, "");
  // console.log("values====>"+unhedgeValue); //

  let format_num_unhedge = unhedgeValue.split(".");
  // console.log("FORMAT==>"+format_num_unhedge);
  console.log(format_num_unhedge);
  if (format_num_unhedge.length > 2) {
    format_num_unhedge = [
      format_num_unhedge[0],
      format_num_unhedge.slice(1).join(""),
    ];
  }
  console.log(format_num_unhedge);

  if (format_num_unhedge.length > 1) {
    format_num_unhedge[1] = format_num_unhedge[1].substring(0, 2);
  }

  format_num_unhedge[0] = parseFloat(format_num_unhedge[0]).toLocaleString();
  res_unhedge_effec_price = format_num_unhedge.join(".");
  // console.log("first input value===>" + res_unhedge_effec_price);
  if (res_unhedge_effec_price === "NaN") {
    clicksInput.value = "";
} else {
    // Update the input value
    clicksInput.value = res_unhedge_effec_price;
}
  // clicksInput.value = res_unhedge_effec_price;
}


function display_unhedge(valueyear) {
  
  let unhedge = document.getElementById("unhedge_effective_block");
  if (unhedge.style.display == "none") {
    unhedge.style.display = "block";
  }

  // else {
  //   alert('22');
  //   unhedge.style.display = "none";
  // }

  let contract = [];
  let tempArr = [];
  let contracts = document.querySelectorAll(".contractscheckbox:checked");
  let viewValue = $(".view:checked").val();
  // alert(viewValue);
  for (var i = 0; i < contracts.length; i++) {
    contract = contract + "," + contracts[i].value;
    tempArr.push(contract[i].value);
  }
  if (contract[0] == ",") {
    contract = contract.slice(1);
  }
  console.log("contractsYear====>" + contract);
  let hedgingEffectiveDiv = document.getElementById("unhedged_effective_div");

  $.ajax({
    url: "ajax/displayMonthsCPR.php",
    method: "POST",
    data: {
      contractID: contract,
      year: valueyear,
      viewValue: viewValue,
    },
    success: function (data) {
      $("#unhedged_effective_div").html(data);
    },
  }).done(function (data) {
    // console.log("123");
    let applyAllButton = document.getElementById("apply_all_cpr");
    let unhedge_all_inputs = document.querySelectorAll(".unhedgeInput");
    // console.log(unhedge_all_inputs.length);
    unhedge_all_inputs[0].addEventListener("input", function () {
      if (this.value !== "") {
        // console.log("1111===>"+this.value.trim());
        applyAllButton.style.display = "block"; // Show the button
      } else {
        // alert(this.value);
        applyAllButton.style.display = "none"; // Hide the button
      }
    });
    let all_values = [];
    applyAllButton.addEventListener("click", function () {
      let firstValue = document.getElementById("hedgevalmon0").value; // first input value
      let passValues = document.getElementById('valuesID');  
      // console.log("1st val===>" + firstValue);
      for (let i = 1; i < unhedge_all_inputs.length; i++) {
        unhedge_all_inputs[i].value = firstValue;
        all_values.push(unhedge_all_inputs[i].value);
        unhedge_all_inputs[i].readOnly = true;
        unhedge_all_inputs[i].style.outline="none";
        unhedge_all_inputs[i].style. background= "#eee";
      

      }
      
      // console.log(all_values.replaceAll(',',''));
      passValues.value = firstValue+','+all_values; //unhedgevalues passing to fetch from backend
   
    });
    
    // console.log( "values====>"+unhedge_all_inputs.value);
    for (let i = 1; i < unhedge_all_inputs.length; i++) {

      // console.log("length===>" + unhedge_all_inputs.length);
      unhedge_all_inputs[i].addEventListener("click", function () {
        let firstValue = document.getElementById("hedgevalmon0").value; // first input value
  // console.log("1st val===>" + firstValue);
        alert("Values cannot be changed in the middle of the month.");
        unhedge_all_inputs[i].readOnly = true;
        unhedge_all_inputs[i].style.outline="none";
        // if()

      });
    }
  });

  let unhedge_all_inputs1 = document.querySelectorAll(".hedgevalmon0");
    console.log(unhedge_all_inputs1);
}
// console.log('111');
// alert("11");

// }

// function view_checked(viewValue){
//   alert(viewValue);
//   let contract = [];
//   let tempArr = [];
//   let valueyear= document.querySelector(".contactType_CPR:checked");
//   alert(valueyear);
//   let contracts = document.querySelectorAll(".contractscheckbox:checked");
//   // let viewValue = $(".view:checked").val();
//   // alert(viewValue);
//   for (var i = 0; i < contracts.length; i++) {
//     contract = contract + "," + contracts[i].value;
//     tempArr.push(contract[i].value);
//   }
//   if (contract[0] == ",") {
//     contract = contract.slice(1);
//   }
//   console.log("contractsYear====>"+contract);
//   let hedgingEffectiveDiv = document.getElementById('unhedged_effective_div');

//   $.ajax({
//   url: "ajax/displayMonthsCPR.php",
//   method: "POST",
//   data: {
//     contractID: contract,
//     year: valueyear,
//     viewValue:viewValue
//   },
//   success: function (data) {
//     $("#unhedged_effective_div").html(data);
//   },
// });
// }
